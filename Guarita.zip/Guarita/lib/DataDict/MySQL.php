<?php

class Lumine_DataDict_MySQL extends Lumine_DataDict
{
}


?>