<?php
$con = mysqli_connect("localhost","u383835249_user","ifesifes123","u383835249_banco");

$host="localhost";
$login="u383835249_user";
$senha= "ifesifes123";
$bancoDados="u383835249_banco";


// Check connection
if (mysqli_connect_errno())
  {
  echo "Falha na Conexão: " . mysqli_connect_error();
  }
?>


